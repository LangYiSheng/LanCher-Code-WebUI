from lancher_code.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
